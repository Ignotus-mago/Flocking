// Processing does not support enums, so they have to be declared in .java files.
// CIRCLE, BLUENOISE, GRIDTRIPLETS, etc....
enum BoidPlacement {GRID, CENTER, RANDOM, RANDOMCENTER, CENTERGRID, GRIDTRIPLETS;}

