public interface BoidCallbackINF {
  /**
   * @param boid   the Boid instance calling callback
   */
  public void callback(Boid boid);
}

